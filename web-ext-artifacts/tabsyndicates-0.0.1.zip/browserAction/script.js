document.getElementById("myHeading").style.color = "red";

console.log(localStorage.getItem("fuck"));
