
futureme: sorry buddy
SyndicateForum is a tab where the syndicate gathers and tells story 
btw this is an "extension page"